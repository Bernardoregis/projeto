
<!DOCTYPE html>
<html>
<head>
    <!-- Standard Meta -->
    <meta charset="utf-8" />
    <title>Cadastro</title>
    <link rel="stylesheet" href="semantic.css" type="text/css">
    <script type="text/javascript" src="semantic.js">

        $('.ui.checkbox')
            .checkbox()
        ;
    </script>
    <style type="text/css">
        body {
            background-image: url(https://images4.alphacoders.com/197/197734.jpg);
        }
        body > .grid {
            height: 100%;
        }

        .column {
            max-width: 450px;
        }
        .ui.stacked.segment{
            width: 350px;

        }
    </style>
</head>
<body>


<div class="ui middle aligned center aligned grid">
    <div class="column">

        <form class="ui form">
            <div class="ui stacked segment">
                <div class="field">
                    <h2 class="ui orange header">
                        BBG GAMES
                    </h2>
                    <h3 class="ui orange header">Cadastro de Resenha</h3>
                    <div class="ui left icon input">
                        <i class="address card icon"></i>
                        <input type="text" name="titulo" placeholder="Nome do jogo">
                    </div>
                </div>
                <div class="field">
                    <div class="ui left icon input">
                        <i class="pencil alternate icon"></i>
                        <input type="text" name="desenvolvedores" placeholder="Desenvolvedores">
                    </div>
                </div>
                <div class="field">
                    <div class="ui left icon input">
                        <i class="square full icon"></i>
                        <input type="text" name="plataforma" placeholder="Plataformas">
                    </div>
                </div>
                <div class="field">
                    <div class="ui left icon input">
                        <i class="chess rook icon"></i>
                        <input type="text" name="modoDejogo" placeholder="Modo de jogo">
                    </div>
                </div>
                <div class="ui form">
                    <div class="field">
                        <label>Gameplay</label>
                        <textarea rows="5"></textarea>
                    </div>
                    <div class="field">
                        <label>Mapas</label>
                        <textarea rows="2"></textarea>
                    </div>
                </div><br>

                <a class="ui fluid large orange submit button" href="perfil.php">Cadastrar Resenha</a><br>
                <hr>
                <a href="index2.php">Volte para a página inicial.</a>
            </div>



        </form>


    </div>
</div>
