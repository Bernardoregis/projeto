<?php
        $resenhas = file_get_contents("data_bases/resenhaCadastrada.json");
        $array = json_decode($resenhas, true);

        $ranking = $array;

        sort($ranking);

        foreach($ranking as $item){
            echo $item['nota']." - ";
        }