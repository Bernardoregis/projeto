<?php
    $json = file_get_contents("avaliacao.json");
    $array = json_decode($json, true);


?>
<html>
<head>
    <link rel="stylesheet" href="semantic.css" type="text/css">
    <script type="text/javascript" src="semantic.js"></script>

</head>
<body>

<div class="ui icon">

   <form method="get">
       <select>
           <option>Nota</option>
           <option><i class="star icon">1</i></option>
           <option><i class="star icon">2</i></option>
           <option><i class="star icon">3</i></option>
           <option><i class="star icon">4</i></option>
           <option><i class="star icon">5</i></option>

       </select>
   </form>

</div>
</body>
</html>
