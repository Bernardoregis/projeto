<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="semantic.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/css.css">
    <script type="text/javascript" src="semantic.js"></script>

    <meta charset="UTF-8">
    <title>BBG Games</title>
</head>
<body>
<img src="img/logo.png" width="150" style="position: absolute;">
<div id="titulo" style="text-align: center; ">
    <h1>Seja bem vindo ao BBG Games</h1>
    <h2>Uma metralhadora de notícias.</h2>
</div>
<div class="ui pointing menu" id="menu" style="padding-left: 10%">
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="index.php">
        Home
    </a>
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="jogos.php">
        Jogos
    </a>
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="noticias.php">
        Notícias
    </a>
    <a class="active item" style="padding-left: 30px; padding-right: 30px;" href="novidades.php">
        Novidades
    </a>
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="contato.php">
        Fale Conosco
    </a>
    <div class="right menu" style="padding-right: 10%; border: 5px;">
        <form method="get" action="pesquisa.php">
            <div class="ui icon input">
                <input type="text" id="pesquisar" name="pesquisar" placeholder="Search...">
                <i class="circular search link icon"></i>
            </div>
        </form>
    </div>
    <a class="item" href="telaLogin.php">
        <i class="sign in alternate icon"></i>
    </a>
</div>
</div>
</body></html>