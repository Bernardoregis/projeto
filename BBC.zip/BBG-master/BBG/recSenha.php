
<!DOCTYPE html>
<html>
<head>
    <!-- Standard Meta -->
    <meta charset="utf-8" />
    <title>Recuperação de Senha</title>
    <link rel="stylesheet" href="semantic.css" type="text/css">
    <script type="text/javascript" src="semantic.js"></script>
    <style type="text/css">
        body {
            background-image: url(https://images4.alphacoders.com/197/197734.jpg);
        }
        body > .grid {
            height: 100%;
        }

        .column {
            max-width: 350px;
        }

    </style>
</head>
<body>


<div class="ui middle aligned center aligned grid" id="login">
    <div class="column">

        <form class="ui large form" method="post" action="index2.php">
            <div class="ui stacked segment">
                <div class="field">

                    <h2 class="ui orange header">
                        BBG GAMES
                    </h2>
                    <div class="ui left icon input">
                        <i class="mail icon"></i>
                        <input type="text" id="email"  name="email" placeholder="Email" required>
                    </div>
                </div>
                <div class="field">
                    <div class="ui left icon input">
                        <i class="lock icon"></i>
                        <input type="password" id="senha" name="senha" placeholder="Digite a última senha que você lembra" required>
                    </div><br><br>
                <div class="ui left icon input">
                    <i class="mail icon"></i>
                    <input type="text" id="email"  name="email" placeholder="Email de recuperação" required><br>
                </div></div><br><br>
                <input class="ui orange button" type="submit" value="Enviar Código de Recuperação">
                <a href="telaLogin.php" style="padding-left: 15px;">          Voltar</a>
                <hr>
                <a href="index.php">Voltar para página inicial</a>
            </div>



        </form>

    </div>
</div>


</body>

</html>