<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="semantic.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/css.css">
    <script type="text/javascript" src="semantic.js"></script>

    <meta charset="UTF-8">
    <title>Contato</title>
</head>
<body>
<img src="img/logo.png" width="150" style="position: absolute;">
<div id="titulo" style="text-align: center; ">
    <h1>Seja bem vindo ao BBG Games</h1>
    <h2>Uma metralhadora de notícias.</h2>
</div>
<div class="ui pointing menu" id="menu" style="padding-left: 10%">
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="index2.php">
        Home
    </a>
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="jogos2.php">
        Jogos
    </a>
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="noticias2.php">
        Notícias
    </a>
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="novidades2.php">
        Novidades
    </a>
    <a class="active item" style="padding-left: 30px; padding-right: 30px;" href="contato2.php">
        Fale Conosco
    </a>
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="faq.php">
        FAQ
    </a>
    <div class="right menu" style="padding-right: 10%; border: 5px;">
        <form method="get" action="pesquisa2.php">
            <div class="ui icon input">
                <input type="text" id="pesquisar" name="pesquisar" placeholder="Search...">
                <i class="circular search link icon"></i>
            </div>
        </form>
    </div>
    <a class="item" href="perfil.php">
        <i class="user outline icon"></i>
    </a>
    <a class="item" href="cadastraResenha.php">
        <i class="file alternate outline icon"></i>
    </a>
    <a class="item" href="index.php">
        <i class="sign out alternate icon"></i>
    </a>
</div>
</div>

<div class="ui raised very padded text container segment" id="resenha">
    <h2 class="ui header">criadores:</h2>
    <p>bernardinho bernardao:
        47 997323012
        Bernardoregis2010@gmail.com
        <a href="https://www.facebook.com/bernardo.regis.9" class="icon facebook"> facebook</a></p>
    <!--<p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eget ligula eu lectus lobortis condimentum. Aliquam nonummy auctor massa. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nulla at risus. Quisque purus magna, auctor et, sagittis ac, posuere eu, lectus. Nam mattis, felis ut adipiscing."</p>
    --!>
    <div class="image" >
        <img src="https://scontent.ffln5-1.fna.fbcdn.net/v/t1.0-9/14931_625883537509878_8960141994484798989_n.jpg?_nc_cat=100&_nc_ht=scontent.ffln5-1.fna&oh=277dc0cfa92a598a9e20b6df6e1fc776&oe=5C9F22C5" style="width: 500px">
    </div>

</body></html>