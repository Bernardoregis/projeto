<?php
    $array_curtida = file_get_contents('curtidas.json');
    $leCurtida = json_decode($array_curtida);

        if($leCurtida > 0){
            descurtir($leCurtida);
            $like = "curtir";
        }else{
            curtir($leCurtida);
            $like = "descurtir";
        }

    function curtir($leCurtida)
    {
        $like = $_GET['curtir'];
        if ($like == "curtir") {
            $curtir = 1;
            if ($curtir == 1) {
                $leCurtida = $leCurtida + 1;
            }
        }
        $array_curtir = json_encode($leCurtida);
        $enviacurtida = file_put_contents('curtidas.json', $array_curtir, JSON_PRETTY_PRINT);
    }
    function descurtir ($leCurtida){
        $like = $_GET['curtir'];
        if ($like == "curtir") {
            $curtir = 1;
            if ($curtir == 1) {
                $leCurtida = $leCurtida - 1;
            }
        }
        $array_curtir = json_encode($leCurtida);
        $envia = file_put_contents('curtidas.json', $array_curtir, JSON_PRETTY_PRINT);
    }

?>

<html>
        <head>
            <link rel="stylesheet" href="semantic.css" type="text/css">
            <script type="text/javascript" src="semantic.js"></script>

        </head>
    <body>

    <div>
        <form method="get">
            <div class="ui labeled button" tabindex="0">
                <div class="ui red button">
                    <i class="heart icon"></i><input class="ui labeled button" type="submit" value ="<?= $like; ?>" name="curtir" id="curtir">
                </div>
                <a class="ui basic red left pointing label">
                    <?php $sla = 2345;
                    $le = $_GET['curtir'];
                    if ($le == "curtir") {
                        $curtir = 1;
                        if ($curtir == 1) {
                            $leCurtida = $sla + 1;
                            echo $leCurtida;
                        }
                    }else{
                        echo $sla;
                    }
                    ?>
                </a>

        </form>
    </div>
    </body>
</html>
