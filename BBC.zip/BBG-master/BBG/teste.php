<?php
$array_usuarios = file_get_contents('data_bases/usuarios.json');
$array = json_decode($array_usuarios, true);


?>
<html>
    <head>

    </head>
    <body>

        <form method="post" action="edit.php">

        <div class="ui cards"><?php foreach($array as $item): ?>
            <div class="card">
                <?= $item['nome'] ?>
                <input type="submit" value="editar">
            </div>
        <?php endforeach;?>
        </div>
        </form>
    </body>


</html>