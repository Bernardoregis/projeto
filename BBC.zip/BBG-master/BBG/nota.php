<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="semantic.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/css.css">
    <script type="text/javascript" src="semantic.js"></script>

    <meta charset="UTF-8">
    <title>BBG Games</title>
</head>
<body>

<div class="ui right labeled input">
    <select class="ui button yellow">
    <option>Nota</option>
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
        <option>5</option>
    </select>
    <input type="submit" class="ui button yellow" value="Enviar Nota">
</div>

</body></html>