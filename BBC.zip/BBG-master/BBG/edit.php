<?php

    $valor = $_POST;


function edit()
{
    $array_usuarios = file_get_contents('data_bases/usuarios.json');
    $array = json_decode($array_usuarios);

    $post[] = $_GET;
    $values = json_encode($array, JSON_PRETTY_PRINT);

// Armazena no final do arquivo os valores recebidos.
    file_put_contents('data_bases/usuarios.json', $values);
}
$_GET = edit();
?>
<html>
    <head>

    </head>
    <body>

        <form method="get">

        <div class="ui cards">
            <div class="card">
                <input type="text" value="<?php $post; ?>">
                <input type="submit" value="editar">
            </div>
        </div>
        </form>
    </body>


</html>