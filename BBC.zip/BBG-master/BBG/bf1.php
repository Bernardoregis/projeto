<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="semantic.css" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/css.css">
    <script type="text/javascript" src="semantic.js"></script>

    <meta charset="UTF-8">
    <title>BBG Games</title>
</head>
<body>
<img src="img/logo.png" width="150" style="position: absolute;">
<div id="titulo" style="text-align: center; ">
    <h1>Seja bem vindo ao BBG Games</h1>
    <h2>Uma metralhadora de notícias.</h2>
</div>
<div class="ui pointing menu" id="menu" style="padding-left: 10%">
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="index.php">
        Home
    </a>
    <a class="active item" style="padding-left: 30px; padding-right: 30px;" href="jogos.php">
        Jogos
    </a>
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="noticias.php">
        Notícias
    </a>
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="novidades.php">
        Novidades
    </a>
    <a class="item" style="padding-left: 30px; padding-right: 30px;" href="contato.php">
        Fale Conosco
    </a>
    <div class="right menu" style="padding-right: 10%; border: 5px;">
        <form method="get" action="pesquisa.php">
            <div class="ui icon input">
                <input type="text" id="pesquisar" name="pesquisar" placeholder="Search...">
                <i class="circular search link icon"></i>
            </div>
        </form>
    </div>

    <a class="item" href="telaLogin.php">
        <i class="sign in alternate icon"></i>
    </a>
</div>
<div class="ui raised very padded text container segment" id="resenha">
    <h2 class="ui header">Battlefield 1</h2>
    <p><b>Desenvolvedor: </b>EA.</p>
    <p><b>Plataforma: </b>PC, PS4, Xbox One.</p>
    <p><b>Gameplay: </b>Semelhante aos jogos anteriores da série, Battlefield 1 é um jogo de tiro em primeira pessoa. Ele ocorre no período da Primeira Guerra Mundial, e é inspirado em fatos históricos. Os jogadores podem fazer uso de armas usadas neste conflito, incluindo rifles de ferrolho, armas automáticas e semi-automáticas, artilharia, lança-chamas, gás mostarda e metralhadoras para matar oponentes.

        O multiplayer do jogo suporta até 64 jogadores. Os mapas são baseados em localidades ao redor do mundo, incluindo a Arábia, a frente ocidental, e os alpes.</p>
    <p><b>Mapas: </b>Ballrom Blitz, Argonne Forest, Fao Fortress, Suez, St Quentin Scar, Sinai Desert, Amiens, Monte Grappa, Empire's Edge, Giant's Shadow.</p>
    <div class="image" >
        <img src="img/bf1.jpg" style="width: 500px">
    </div>

    Comentários:
    <div id="comentario">
        <div class="column">
            <div class="ui raised segment">
                <a class="ui grey ribbon label">Pedrinho chavozinho</a>
                <p>salkfhsalk jjdfks af lksa fnksafn mlksan</p>
                <div class="ui divider"></div>
                <a class="ui grey ribbon label">Alissinho gamer 777</a>
                <p>jogo top, curti skr skr top top</p>
            </div>
        </div>
    </div>
</div>


</body></html>
