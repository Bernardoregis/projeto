<?php

function logar()
{
    $json = file_get_contents("data_bases/cadastrados.json");
    $usuarios = json_decode($json, true);
    $login = $_POST['login'];
    $senha = $_POST['senha'];

    foreach ($usuarios as $usuario) {

        if ($login == $usuario['login'] AND $senha == $usuario['senha']) {

            header("location: index2.php");

        }else{
           header("location: telaLogin.php?msg=insira_um_login_valido");

        }
    }

}
logar();
function digaOla()
{
    $json = file_get_contents("data_bases/cadastrados.json");
    $usuarios = json_decode($json, true);
    $login = $_POST['login'];
    $senha = $_POST['senha'];

    $loginSucesso = true;
    foreach ($usuarios as $usuario) {

        if ($login == $usuario['login'] AND $senha == $usuario['senha']) {
            $loginSucesso = false;
            echo "Bem vindo $login";
        }
    }
}
digaOla();


?>